from scrapy import cmdline

cmdline.execute('scrapy crawl bmw5_v1'.split())
